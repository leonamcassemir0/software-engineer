package com.example.demomvc.dao;

import org.springframework.stereotype.Repository;

import com.example.demomvc.entity.Tarefa;
@Repository
public class TarefaDaoImpl extends AbstractDao<Tarefa, Long> implements TarefaDao  {

}