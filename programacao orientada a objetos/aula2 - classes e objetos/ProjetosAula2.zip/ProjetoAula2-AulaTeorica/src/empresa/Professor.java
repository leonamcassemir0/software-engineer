package empresa;

public class Professor {
	String nome;
	String formacao;
	int cadastro;

}
