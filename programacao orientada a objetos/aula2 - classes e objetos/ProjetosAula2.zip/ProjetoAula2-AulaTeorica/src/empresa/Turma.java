package empresa;

import java.util.ArrayList;

public class Turma {
	String nome;
	Professor prof;
	ArrayList<Aluno> alunos;
	
	

}
