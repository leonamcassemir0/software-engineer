package empresa;

public class ValorInvalidoException extends Exception{

}
