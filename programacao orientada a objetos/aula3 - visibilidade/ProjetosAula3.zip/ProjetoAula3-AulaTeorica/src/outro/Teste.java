package outro;

import empresa.Aluno;

public class Teste {
	
	public static void teste() {
		Aluno a = new Aluno(1001,"Super Mario","222.333.444-55");
	}

}
